<?php
namespace CORE\db;

class Lock{
	private $_lockStr ='';
	private $_originalStr;
	
	public function __construct($code=''){
		$this->_originalStr = $code;
	}
	
	//////////////
	public function getLock(){
		
		$codeArray = str_split($this->_originalStr);
		$count = count($codeArray);
		foreach($codeArray as $v){
			$this->_lockStr .= chr(ord($v)+$count);
		}
		return $this->_lockStr;
	}
	
	public function getKey (){
		$codeArray = str_split($this->_originalStr);
		$count = count($codeArray);
		foreach($codeArray as $v){
			$this->_lockStr  .= chr(ord($v)-$count);
		}
		return $this->_lockStr;
	}	
}

