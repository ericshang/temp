<?php

use app\models\NavModel;

if(isset($_NAV) === false ){
	/*
	$_NAV = array(
		"Home" => "http://localhost/",
		"Item" => "http://localhost/Item/Index/"
	);
	*/
	
	$_NAV = (new NavModel())->getNav();
	
}

