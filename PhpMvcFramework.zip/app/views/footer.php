
<div class="FOOTER">
	<a href='http://localhost/'>Home</a> | <a href='http://localhost/item/'>Item</a> | <a href='http://localhost/item/manage/'>Manage</a>
</div>
</body>
</html>