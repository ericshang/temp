<?php 
require_once(VIEW_PATH.'/nav.php');
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo $title ?></title>
    <link rel="stylesheet" href="/resource/css/main.css" type="text/css" />
</head>
<body>
<?php
	if(isset($_NAV)){
		foreach($_NAV as $nav){
			echo "<a href='".$nav['url']."'>".$nav['name']."</a> ";
		}
	}
?> 
    <h1><?php echo $title ?></h1>